import json, os, time, urllib.request, sys
P = json.load(open('fulltext/picked.json'))
D = 'fulltext/pdfs'; LOG = 'fulltext/download_log.json'
log = json.load(open(LOG)) if os.path.exists(LOG) else {}
UA = {'User-Agent': 'Mozilla/5.0 (research-pilot)'}
def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read(25_000_000)
for person in P:
    for c in person['papers']:
        wid = c['wid']; fn = f'{D}/{wid}.pdf'
        if log.get(wid, {}).get('ok'): continue
        urls = []
        if c['arxiv']: urls.append(('arxiv', f"https://arxiv.org/pdf/{c['arxiv']}"))
        for u in (c['pdf'], c['oa']):
            if u and 'arxiv' not in u and u not in [x[1] for x in urls]: urls.append(('oa', u))
        res = {'ok': False, 'tried': []}
        for kind, u in urls:
            try:
                data = get(u)
                if data[:5] == b'%PDF-':
                    open(fn, 'wb').write(data); res = {'ok': True, 'src': kind, 'url': u, 'bytes': len(data)}; break
                res['tried'].append([u, 'not a PDF'])
            except Exception as e:
                res['tried'].append([u, str(e)[:80]])
            time.sleep(3.1 if kind == 'arxiv' else 1)
        else:
            pass
        if res['ok'] and res['src'] == 'arxiv': time.sleep(3.1)
        log[wid] = res
        json.dump(log, open(LOG, 'w'), indent=0)
        print(person['name'], wid, res.get('src', 'FAIL'), flush=True)
ok = sum(1 for v in log.values() if v['ok'])
print('DONE', ok, 'of', len(log))
