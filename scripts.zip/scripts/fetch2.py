import json,urllib.request,time,os,sys
SEL='id,doi,title,publication_year,type,primary_location,cited_by_count,topics,keywords,abstract_inverted_index,authorships,open_access'
F='tech_pilot/works.json'
cache=json.load(open(F)) if os.path.exists(F) else {}
C=json.load(open('tech_pilot/candidates.json'))
spent=0;err=0
for x in C:
    aid=x['openalex'].rstrip('/').split('/')[-1]
    if aid in cache: continue
    out=[];cursor='*'
    try:
        while cursor:
            u=f'https://api.openalex.org/works?filter=author.id:{aid}&per-page=200&select={SEL}&cursor={cursor}'
            with urllib.request.urlopen(u,timeout=60) as r: j=json.load(r)
            spent+=j['meta'].get('cost_usd') or 0
            out+=j['results'];cursor=j['meta'].get('next_cursor')
            if len(out)>=400 or not j['results']: break
            time.sleep(0.15)
        cache[aid]=out
    except Exception as e:
        print('ERR',aid,e);err+=1
        if err>3: break
    if len(cache)%25==0: json.dump(cache,open(F,'w'),ensure_ascii=False)
json.dump(cache,open(F,'w'),ensure_ascii=False)
print('authors',len(cache),'works',sum(len(v) for v in cache.values()),'spent',round(spent,4),'errors',err)
