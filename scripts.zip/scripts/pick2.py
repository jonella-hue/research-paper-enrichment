import json,re,collections
oa=json.load(open('oa_rows.json'));used={x['school']+str(x['row']) for x in json.load(open('pilot_candidates.json'))}
TECH=re.compile(r'computer|electrical|eecs|\bphysics\b|applied physics|course vi\b|course vi-|course viii',re.I)
EXCL=re.compile(r'astro|biophys|business|plasma',re.I)
def n(x):
    try:return int(float(str(x).replace(',','')))
    except:return 0
def spread(l,k): return l if len(l)<=k else [l[int(i*len(l)/k)] for i in range(k)]
out=[]
for sh,L in oa.items():
    pool=[o for o in L if TECH.search(o['prog'] or '') and not EXCL.search(o['prog'] or '') and sh+str(o['row']) not in used
          and o['status']=='Verified (OpenAlex)' and 3<=n(o['pubs'])<=150 and o['link']]
    p=spread(pool,25)
    for x in p: out.append(dict(x,school=sh,openalex=x['link'],scholar=x.get('w',''),src='OpenAlex'))
    print(sh,len(pool),'->',len(p),collections.Counter(('CS/EE' if re.search(r'comput|electr|eecs|course vi',x['prog'],re.I) else 'Physics') for x in p))
json.dump(out,open('tech_pilot/candidates.json','w'),ensure_ascii=False,indent=0)
print('total',len(out))
