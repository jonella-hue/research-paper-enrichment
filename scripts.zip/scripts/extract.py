import json, re, os, sqlite3, sys, unicodedata, logging
logging.getLogger('pypdf').setLevel(logging.ERROR)
from pypdf import PdfReader
P = json.load(open('fulltext/picked.json'))
log = json.load(open('fulltext/download_log.json'))
W = json.load(open('tech_pilot/works.json'))
absmap = {}
for ws in W.values():
    for x in ws:
        ii = x.get('abstract_inverted_index')
        if ii:
            pos = {}
            for word, idxs in ii.items():
                for i in idxs: pos[i] = word
            absmap[x['id'].split('/')[-1]] = ' '.join(pos[i] for i in sorted(pos))
SEC = re.compile(r'^\s*(?:[0-9]{1,2}(?:\.[0-9])?\.?\s+|[IVX]{1,4}\.\s+)?(Abstract|Introduction|Background|Related Work|Preliminaries|Method|Methods|Methodology|Approach|Design|Implementation|Evaluation|Experiments?|Experimental Setup|Results|Discussion|Conclusions?|Limitations|Future Work|Acknowledg(?:e)?ments?|Appendix)\b', re.I)
REF = re.compile(r'^\s*(?:[0-9]{1,2}\.?\s+)?(References|Bibliography|REFERENCES)\s*$')
def clean(t):
    t = unicodedata.normalize('NFKC', t)
    t = t.replace('­', '').replace('�', '')
    t = re.sub(r'-\n(?=[a-z])', '', t)
    return t
people, papers, passages = [], [], []
for pi, person in enumerate(P):
    people.append({k: person[k] for k in ('key', 'name', 'school', 'program', 'fit', 'role', 'why', 'openalex')})
    for c in person['papers']:
        st = log.get(c['wid'], {})
        rec = {'wid': c['wid'], 'p': pi, 'title': c['title'], 'year': c['year'], 'cites': c['cites'], 'doi': c['doi'],
               'abs': absmap.get(c['wid'], ''), 'ok': bool(st.get('ok')), 'src': st.get('src', ''), 'url': st.get('url', ''), 'pages': 0, 'words': 0, 'why_fail': ''}
        if not rec['ok']:
            rec['why_fail'] = (st.get('tried') or [['', 'no free PDF link']])[-1][1]
            papers.append(rec); continue
        try:
            rd = PdfReader(f"fulltext/pdfs/{c['wid']}.pdf")
            pages = [clean(pg.extract_text() or '') for pg in rd.pages[:60]]
        except Exception as e:
            rec['ok'] = False; rec['why_fail'] = 'could not read PDF: ' + str(e)[:60]; papers.append(rec); continue
        rec['pages'] = len(rd.pages)
        section = 'Start'; buf = []; buf_page = 1; stop = False; words = 0
        def flush(pg):
            global buf
            text = re.sub(r'\s+', ' ', ' '.join(buf)).strip()
            if len(text.split()) >= 12:
                passages.append([len(papers), pg, section, text])
            buf = []
        for pno, ptxt in enumerate(pages, 1):
            if stop: break
            for line in ptxt.split('\n'):
                if REF.match(line):
                    stop = True; break
                m = SEC.match(line)
                if m and len(line.strip()) < 60 and len(line.split()) <= 7 and (line.strip()[0].isupper() or line.strip()[0].isdigit()):
                    if buf: flush(buf_page)
                    section = m.group(1).title(); buf_page = pno
                buf.append(line); words += len(line.split())
                if sum(len(x.split()) for x in buf) >= 130:
                    flush(buf_page); buf_page = pno
            if buf and sum(len(x.split()) for x in buf) >= 130: flush(buf_page)
            buf_page = pno if not buf else buf_page
        if buf: flush(buf_page)
        rec['words'] = words
        if words < 300: rec['ok'] = False; rec['why_fail'] = 'PDF had no readable text (scanned image?)'
        papers.append(rec)
# drop passages of papers that failed after reading
passages = [x for x in passages if papers[x[0]]['ok']]
json.dump({'people': people, 'papers': papers, 'passages': passages}, open('fulltext/ft_data.json', 'w'), ensure_ascii=False, separators=(',', ':'))
# SQLite database with full-text search
if os.path.exists('fulltext/papers_fulltext.db'): os.remove('fulltext/papers_fulltext.db')
db = sqlite3.connect('fulltext/papers_fulltext.db')
db.executescript('''
create table people(id integer primary key, person_key, name, school, program, fit, role, why, openalex);
create table papers(id integer primary key, person_id, openalex_work, title, year, citations, doi, pdf_url, pdf_source, pages, words, has_full_text, abstract);
create virtual table passages using fts5(text, section, paper_id unindexed, page unindexed, tokenize="porter unicode61");
create virtual table abstracts using fts5(text, paper_id unindexed, tokenize="porter unicode61");
''')
for i, p in enumerate(people): db.execute('insert into people values (?,?,?,?,?,?,?,?,?)', (i, p['key'], p['name'], p['school'], p['program'], p['fit'], p['role'], p['why'], p['openalex']))
for i, r in enumerate(papers):
    db.execute('insert into papers values (?,?,?,?,?,?,?,?,?,?,?,?,?)', (i, r['p'], r['wid'], r['title'], r['year'], r['cites'], r['doi'], r['url'], r['src'], r['pages'], r['words'], int(r['ok']), r['abs']))
    db.execute('insert into abstracts values (?,?)', (r['title'] + ' ' + r['abs'], i))
for pid, pg, sec, text in passages: db.execute('insert into passages values (?,?,?,?)', (text, sec, pid, pg))
db.commit()
ok = [r for r in papers if r['ok']]
print('papers', len(papers), 'full text', len(ok), 'passages', len(passages), 'words', sum(r['words'] for r in ok), 'abs words', sum(len(r['abs'].split()) for r in ok))
from collections import Counter
print(Counter(r['why_fail'][:40] for r in papers if not r['ok']))
