import json, sys
sys.path.insert(0, '.')
from role_map import M
p1 = json.load(open('built.json'))
p2 = json.load(open('tech_pilot/built2.json'))
r2 = json.load(open('tech_pilot/roles2.json'))
def clean_fit(f):
    for e in ('✅ ', '🟡 ', '❌ '): f = f.replace(e, '')
    return f
people, papers, idx = [], [], {}
def add_people(rows, roles, pilot):
    for i, p in enumerate(rows):
        fit, role, why = roles[i]
        key = p[0]
        if key in idx:  # same person key twice: keep first
            continue
        dup = next((j for j, q in enumerate(people) if q['n'] == p[2] and q['s'] == p[1] and q['oa'] and q['oa'] == p[8]), None)
        if dup is not None:  # same person under two degree rows: merge into one candidate
            q = people[dup]; idx[key] = dup
            for f, v in (('d', p[3]), ('pr', p[4]), ('pl', pilot)):
                if v and v not in q[f].split(' & '): q[f] += ' & ' + v
            order = {'Strong': 0, 'Possible': 1, 'No clear fit': 2}
            if order[clean_fit(fit)] < order[q['fit']]: q['fit'], q['role'], q['why'] = clean_fit(fit), role, why
            continue
        idx[key] = len(people)
        people.append({
            'k': key, 's': p[1], 'n': p[2], 'd': p[3], 'pr': p[4],
            'sch': p[7], 'oa': p[8], 'np': p[9], 'na': p[10], 'y0': p[11], 'y1': p[12],
            'tp': p[14], 'fd': p[15], 'kw': p[16],
            'fit': clean_fit(fit), 'role': role, 'why': why, 'pl': pilot})
add_people(p1['people'], [M[r] for r in range(2, 152)], 'Mixed departments')
add_people(p2['people'], r2, 'Tech departments')
seen = set()
for rows in (p1['papers'], p2['papers']):
    for q in rows:
        if q[0] in seen or q[5] not in idx: continue
        seen.add(q[0])
        tk = (idx[q[5]], (q[7] or '').lower().strip())
        if tk in seen: continue  # same paper already listed for this candidate
        seen.add(tk)
        # [person idx, title, year, venue, type, cites, coauthors, topics, keywords, abstract, link, source]
        papers.append([idx[q[5]], q[7], q[8] or 0, q[9], q[10], q[11] or 0, q[12], q[13], q[15], q[16], q[17], q[6]])
papers = [[(c.replace('\ufffd\ufffd', 'φ').replace('\ufffd', '') if isinstance(c, str) else c) for c in r] for r in papers]
json.dump({'people': people, 'papers': papers}, open('library/data.json', 'w'), ensure_ascii=False, separators=(',', ':'))
from collections import Counter
print(len(people), len(papers), sum(1 for x in papers if x[9]), Counter(p['fit'] for p in people))
print(Counter(p['s'] for p in people)); print(Counter(p['role'] for p in people if p['role']))
