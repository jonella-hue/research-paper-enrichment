import json,re,collections,sys
sys.path.insert(0,'.')
SCH=['Harvard University','Princeton University','UC Berkeley','Caltech','MIT','Stanford University']
CODE={'Harvard University':'HAR','Princeton University':'PRI','UC Berkeley':'BER','Caltech':'CAL','MIT':'MIT','Stanford University':'STA'}
C=json.load(open('tech_pilot/candidates.json'));W=json.load(open('tech_pilot/works.json'))
def abstract(inv):
    if not inv: return ''
    return ' '.join(w for i,w in sorted((i,w) for w,ix in inv.items() for i in ix))
def clean(s): return re.sub(r'[\t\r\n]+',' ',s or '').strip()[:49000]
def oa_paper(w):
    pl=w.get('primary_location') or {}; src=(pl.get('source') or {}); tops=w.get('topics') or []
    return {'title':clean(w.get('title')),'year':w.get('publication_year'),'venue':clean(src.get('display_name')),'type':w.get('type') or '',
      'cites':w.get('cited_by_count') or 0,'coauth':'; '.join(a['author']['display_name'] for a in (w.get('authorships') or [])[:10] if a.get('author')),
      'topics':'; '.join(t['display_name'] for t in tops[:3]),'field':(tops[0]['field']['display_name'] if tops and tops[0].get('field') else ''),
      'kw':'; '.join(k['display_name'] for k in (w.get('keywords') or [])[:6]),'abs':clean(abstract(w.get('abstract_inverted_index'))),'link':w.get('doi') or w.get('id')}
ids=collections.Counter(x['openalex'].rstrip('/').split('/')[-1] for x in C)
print('shared ids',[(k,v) for k,v in ids.items() if v>1])
people=[];papers=[]
for x in C:
    sh=x['school'];key=f"{CODE[sh]}-{x['row']:05d}";aid=x['openalex'].rstrip('/').split('/')[-1]
    pl=sorted([oa_paper(w) for w in W.get(aid,[])],key=lambda p:-p['cites'])
    tc=collections.Counter();fc=collections.Counter();kc=collections.Counter()
    for p in pl:
        for t in p['topics'].split('; '):
            if t: tc[t]+=1
        if p['field']: fc[p['field']]+=1
        for k in p['kw'].split('; '):
            if k: kc[k]+=1
    yrs=[p['year'] for p in pl if isinstance(p['year'],int)]
    note='OpenAlex profile from the sheet'+(' (same OpenAlex profile as another person in this pilot)' if ids[aid]>1 else '')
    people.append([key,sh,x['name'],x['deg'],x['prog'],x['status'],note,x.get('scholar','') if 'scholar.google' in (x.get('scholar') or '') else '',x['openalex'],len(pl),sum(1 for p in pl if p['abs']),min(yrs) if yrs else '',max(yrs) if yrs else '','',
                   '; '.join(t for t,_ in tc.most_common(5)),'; '.join(f for f,_ in fc.most_common(3)),'; '.join(k for k,_ in kc.most_common(8))])
    for i,p in enumerate(pl,1):
        papers.append([f"{key}-P{i:03d}",sh,x['name'],x['deg'],x['prog'],key,'OpenAlex',p['title'],p['year'],p['venue'],p['type'],p['cites'],p['coauth'],p['topics'],p['field'],p['kw'],p['abs'],p['link'],'',x['openalex']])
o={s:i for i,s in enumerate(SCH)}
people.sort(key=lambda r:(o[r[1]],r[0]));papers.sort(key=lambda r:(o[r[1]],r[5],-(r[11] or 0)))
json.dump({'people':people,'papers':papers},open('tech_pilot/built2.json','w'),ensure_ascii=False)
print('people',len(people),'papers',len(papers),'abstracts',sum(1 for p in papers if p[16]),'topics',sum(1 for p in papers if p[13]),'zero-paper people',sum(1 for p in people if p[9]==0))
with open('tech_pilot/compact.txt','w') as f:
    for i,p in enumerate(people):
        tt=[q[7][:70] for q in papers if q[5]==p[0]][:3]
        f.write(f"{i+2}|{p[0]}|{p[2]}|{p[4][:28]}|n={p[9]}|T:{p[14][:140]}|K:{p[16][:110]}|P:{' / '.join(tt)}\n")
