import json, re
w = json.load(open('tech_pilot/works.json'))
b = json.load(open('tech_pilot/built2.json')); r2 = json.load(open('tech_pilot/roles2.json'))
EXTRA = ['Xiang Fu', 'Tobia Marcucci', 'Peniel Argaw', 'Michael J. Gerovitch', 'Cathy Hou', 'Indu Panigrahi',
         'Basil Maduros Smitham', 'Rita Frances Sonka', 'Isaac Norman Legred', 'Zachary Bogorad', 'Dimitra A. Pefkou']
def arxiv_id(x):
    s = json.dumps([x.get('primary_location'), x.get('open_access'), x.get('doi')])
    m = re.search(r'arxiv\.org/(?:abs|pdf)/([0-9]{4}\.[0-9]{4,5}|[a-z\-]+/[0-9]{7})', s, re.I) or re.search(r'10\.48550/arxiv\.([0-9]{4}\.[0-9]{4,5})', s, re.I)
    return m.group(1) if m else None
out = []
for i, p in enumerate(b['people']):
    fit, role, why = r2[i]
    if not (fit.startswith('✅') or p[2] in EXTRA): continue
    aid = p[8].rstrip('/').split('/')[-1]
    cands = []
    for x in w.get(aid, []):
        ax = arxiv_id(x); oa = (x.get('open_access') or {}).get('oa_url') or ''
        pdf = (x.get('primary_location') or {}).get('pdf_url') or ''
        if not (ax or oa or pdf): continue
        cands.append({'wid': x['id'].split('/')[-1], 'title': x.get('title') or '', 'year': x.get('publication_year'),
                      'cites': x.get('cited_by_count') or 0, 'arxiv': ax, 'oa': oa, 'pdf': pdf, 'doi': x.get('doi') or ''})
    seen = set(); uniq = []
    for c in sorted(cands, key=lambda c: (c['arxiv'] is None, -c['cites'])):
        t = c['title'].lower().strip()
        if t in seen: continue
        seen.add(t); uniq.append(c)
    out.append({'key': p[0], 'name': p[2], 'school': p[1], 'program': p[4], 'fit': fit, 'role': role, 'why': why, 'openalex': p[8], 'papers': uniq[:8]})
json.dump(out, open('fulltext/picked.json', 'w'), ensure_ascii=False, indent=0)
print(len(out), 'people', sum(len(x['papers']) for x in out), 'papers', sum(1 for x in out for c in x['papers'] if c['arxiv']), 'arxiv')
for x in out: print(x['fit'], x['name'], len(x['papers']))
